<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Thu, 17 Apr 2014 04:03:46 GMT
 */

$lang_block['qr_level'] = 'Chất lượng hình';
$lang_block['qr_pixel_per_point'] = 'Size của QR-code ';
$lang_block['qr_outer_frame'] = 'Đường viền của QR-code';

$lang_block['cominfo_map_guide_title'] = 'Hướng dẫn xây dựng bản đồ Google';
$lang_block['cominfo_map_guide_content'] = '<ul><li>Nhập địa chỉ vào ô, tại danh sách các địa chỉ đổ xuống chọn một địa chỉ hợp lệ với Google MAP.</li><li>Bạn cũng có thể nhấp chuột trái vào bản đồ để tự đánh dấu địa chỉ tùy thích</li><li>Kéo thả chuột trên điểm đánh dấu để di chuyển nó phù hợp với tọa độ địa chỉ công ty của bạn</li><li>Kéo thả chuột trái để di chuyển bản đồ, lăn chuột giữa để có tỷ lệ bản đồ theo ý muốn</li></ul>';
$lang_block['cominfo_map_yes'] = 'Bật Google MAP';
$lang_block['cominfo_map_no'] = 'Tắt Google MAP';
